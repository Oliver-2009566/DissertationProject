using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This script generates the entire map, calling all the necessary functions that are needed to generate an island
// With help from: https://www.youtube.com/watch?v=wbpMiKiSKm8&list=PLFt_AvWsXl0eBW2EiBtl_sxmDtSgZBxB3
public class MapGenerator : MonoBehaviour
{
    public enum DrawMode{NoiseMap, ColorMap, Mesh, FalloffMap};
    public DrawMode drawMode;

    public int mapSize;
    public float noiseScale;
    
    public int octaves;
    [Range(0, 1)]
    public float persistence;
    public float lacunarity;

    public int seed;
    public Vector2 offset;

    public bool useFalloff;

    public float meshHeightMultiplier;
    public AnimationCurve meshHeightCurve;

    public bool autoUpdate;

    public TerrainType[] regions;

    float[,] falloffMap;
    public GameObject plantPrefab;

    // When the game is started, create a falloff map and generate a brand new island
    void Awake()
    {
        falloffMap = FalloffGenerator.GenerateFalloffMap(mapSize);
        GenerateNewMap();
    }
    
    // Randomises some values in order make a brand new island
    public void GenerateNewMap()
    {
        lacunarity = Random.Range(1.9f, 2.1f);
        meshHeightMultiplier = Random.Range(10f, 30f);
        seed = Random.Range(0, 1000000000);
        GenerateMap();
    }
    // Creates a noise map, places L-System plant object around where they should be on the map
    // Subtracts the falloff map if the variable useFalloff is true
    public void GenerateMap()
    {
        float[,] noiseMap = Noise.GenerateNoiseMap(mapSize, mapSize, seed, noiseScale, octaves, persistence, lacunarity, offset);

        for (int i = 0; i < 20; i++)
        {
            int xPos = Random.Range(0, noiseMap.GetLength(0));
            int zPos = Random.Range(0, noiseMap.GetLength(1));
            Vector3 plantPosition = new Vector3((xPos - 125) * 5, meshHeightCurve.Evaluate(noiseMap[xPos, zPos]) * meshHeightMultiplier, (zPos - 125) * 5);

            GameObject plant = Instantiate(plantPrefab);
            plant.transform.localPosition = plantPosition;
        }

        Color[] colorMap = new Color[mapSize * mapSize];
        for(int y = 0; y < mapSize; y++)
        {
            for(int x = 0; x < mapSize; x++)
            {
                if (useFalloff)
                {
                    noiseMap[x, y] = Mathf.Clamp01(noiseMap[x, y] - falloffMap[x,y]);
                }
                float currentHeight = noiseMap[x, y];
                for(int i = 0; i < regions.Length; i++)
                {
                    if(currentHeight <= regions[i].height)
                    {
                        colorMap[y * mapSize + x] = regions[i].color;
                        break;
                    }
                }
            }
        }

        // This calls one of a variety of different draw functions based on what setting the map generator is set to
        MapDisplay display = FindObjectOfType<MapDisplay> ();
        if(drawMode == DrawMode.NoiseMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromHeightMap(noiseMap));  
        }
        else if(drawMode == DrawMode.ColorMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromColorMap(colorMap, mapSize, mapSize));  
        }
        else if (drawMode == DrawMode.Mesh)
        {
            display.DrawMesh(MeshGenerator.GenerateTerrainMesh(noiseMap, meshHeightMultiplier, meshHeightCurve), TextureGenerator.TextureFromColorMap(colorMap, mapSize, mapSize));
        }
        else if (drawMode == DrawMode.FalloffMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromHeightMap(FalloffGenerator.GenerateFalloffMap(mapSize)));
        }
    }

    // Whenever anything is edited in the inspector, it makes sure these variables are clamped
    void OnValidate()
    {
        if (mapSize < 1)
        {
            mapSize = 1;
        }
        if (lacunarity < 1)
        {
            lacunarity = 1;
        }
        if (octaves < 0)
        {
            octaves = 0;
        }
        falloffMap = FalloffGenerator.GenerateFalloffMap(mapSize);
    }
}

// The struct which makes up the different terrain types used by the island
[System.Serializable]
public struct TerrainType
{
    public string name;
    public float height;
    public Color color;
}